Drew Wilson - DrewWilson.com

Please read the license to make sure you abide by it.

You may NOT in any circumstance:
 - Embed the Desktop Font "Pictos.otf" in any web page using any method what-so-ever.
 - Re-distribute the enclosed fonts and files.

You may:
 - Use the Web Fonts to embed into your web pages.