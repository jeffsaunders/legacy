-- cPanel mysql backup
GRANT USAGE ON *.* TO 'dcmclean'@'192.168.1.%' IDENTIFIED BY PASSWORD '120109915552c44c';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean'@'192.168.1.%';
GRANT ALL PRIVILEGES ON `dcmclean\_%`.* TO 'dcmclean'@'192.168.1.%';
GRANT USAGE ON *.* TO 'dcmclean_zc1'@'192.168.1.%' IDENTIFIED BY PASSWORD '3915f5f431e3893f';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean_zc1'@'192.168.1.%';
GRANT USAGE ON *.* TO 'dcmclean_zencart'@'192.168.1.%' IDENTIFIED BY PASSWORD '120109915552c44c';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean_zencart'@'192.168.1.%';
GRANT USAGE ON *.* TO 'dcmclean'@'localhost' IDENTIFIED BY PASSWORD '120109915552c44c';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean'@'localhost';
GRANT ALL PRIVILEGES ON `dcmclean\_%`.* TO 'dcmclean'@'localhost';
GRANT USAGE ON *.* TO 'dcmclean_zc1'@'localhost' IDENTIFIED BY PASSWORD '3915f5f431e3893f';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean_zc1'@'localhost';
GRANT USAGE ON *.* TO 'dcmclean_zencart'@'localhost' IDENTIFIED BY PASSWORD '120109915552c44c';
GRANT ALL PRIVILEGES ON `dcmclean\_zc1`.* TO 'dcmclean_zencart'@'localhost';
