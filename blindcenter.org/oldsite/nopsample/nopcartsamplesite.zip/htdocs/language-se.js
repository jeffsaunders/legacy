//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Din vagn \344r fylld,var v\344nlig att s\344nd order.";
strAdded  = " l\344ggs i din kundvagn.";
strRemove = "Klicka 'Ok' f\366r att ta bort denna produkten fr\345n din kundvagn.";
strILabel = "Produkt Id";
strDLabel = "Produkt namn/Beskrivning";
strQLabel = "Antal";
strPLabel = "Pris";
strSLabel = "Frakt";
strRLabel = "Ta bort fr\345n din kundvagn";
strRButton= "Ta bort";
strSUB    = "SUMMA";
strSHIP   = "FRAKT";
strTAX    = "MOMS";
strTOT    = "SLUT SUMMA TOTALT";
strErrQty = "Felaktigt antal.";
strNewQty = 'Var v\344nlig att skriva in ett nytt antal:';

Language = 'se';
bLanguageDefined = true;

