//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Ostoskorisi on t�ynn�,ole hyv� ja jatka kassalle.";
strAdded  = " lis�tty ostoskoriisi.";
strRemove = "Paina 'Ok' poistaaksesi t�m�n tuotteen ostoskoristasi.";
strILabel = "Tuote Koodi";
strDLabel = "Tuotteen Nimi/Kuvaus";
strQLabel = "M��r�";
strPLabel = "Hinta";
strSLabel = "Kuljetusmaksu";
strRLabel = "Poista ostoskorista";
strRButton= "Poista";
strSUB    = "Yhteens�";
strSHIP   = "Kuljetusmaksu";
strTAX    = "ALV";
strTOT    = "Yhteens�";
strErrQty = "Kpl m��r� ei sallituissa rajoissa.";
strNewQty = 'Ole hyv�, anna uusi kpl m��r�:';

Language = 'fi';
bLanguageDefined = true;

