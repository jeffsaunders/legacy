//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Haraf Maaf! Cart anda telah penuh. Sila ke kaunter bayaran."; 
strAdded  = "di tambah ke shopping cart."; 
strRemove = "Klik 'Ok' untuk keluarkan produk ini dari shopping cart anda."; 
strILabel = "ID #"; 
strDLabel = "Nama Servis"; 
strQLabel = "KUANTITI"; 
strPLabel = "HARGA"; 
strSLabel = "HANTARAN"; 
strRLabel = "Mengurus"; 
strRButton= "Keluarkan"; 
strSUB    = "SUB-JUMLAH"; 
strSHIP   = "HANTARAN"; 
strTAX    = "CUKAI"; 
strTOT    = "JUMLAH"; 
strErrQty = "KUANTITI TIDAK MENCUKUPI"; 
strNewQty = 'Sila masukkan kuantiti baru:'; 

Language = 'my'; 
bLanguageDefined = true; 

