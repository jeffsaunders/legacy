//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//                                                                     ||
//      Script translated in romanian by Florin B                      ||
//               bflorin@zappmobile.ro                                 ||
//---------------------------------------------------------------------||
strSorry  = "Ne pare rau cosul dvs este plin, va rugam comandati acum.";
strAdded  = " adaugat in cos.";
strRemove = "Apasa 'Ok' pentru a elimina acest produs din cos.";
strILabel = "Id Produs";
strDLabel = "Numele produsului/Descriere";
strQLabel = "Cantitate";
strPLabel = "Pret";
strSLabel = "Expeditie";
strRLabel = "Elimina din cos";
strRButton= "Elimina";
strSUB    = "SUBTOTAL";
strSHIP   = "EXPEDITIE";
strTAX    = "TAXE";
strTOT    = "TOTAL";
strErrQty = "Cantitate invalida.";
strNewQty = 'Va rugam introduceti cantitatea:';

Language = 'ro';
bLanguageDefined = true;
