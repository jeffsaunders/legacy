//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "D\351sol\351, votre Caddie est plein !!!";
strAdded  = " a \351t\351 ajout\351 \340 votre Caddie";
strRemove = "Cliquez sur 'Ok' pour retirer le produit de votre Caddie";
strILabel = "Code";
strDLabel = "D\351signation";
strQLabel = "Quantit\351";
strPLabel = "Prix unitaire";
strSLabel = "Autres Frais";
strRLabel = "Retirer du Caddie";
strRButton= "Supprimer l'article !";
strSUB    = "Sous Total";
strSHIP   = "Frais de port";
strTAX    = "Imposition";
strTOT    = "TOTAL";
strErrQty = "Quantit\351 Inadmissible";
strNewQty = 'Veuillez \351crire la nouvelle quantit\351:';

Language = 'fr';
bLanguageDefined = true;

