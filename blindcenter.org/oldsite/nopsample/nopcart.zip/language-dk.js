//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Undskyld, men din indk�bsvogn er fuld, g� venligst til kassen.";
strAdded  = " F�j til din indk�bsvogn.";
strRemove = "Klik 'Ok' for at slet varen fra indk�bsvognen.";
strILabel = "Produkt Id";
strDLabel = "Produkt Navn/Beskrivelse";
strQLabel = "Antal";
strPLabel = "Pris";
strSLabel = "Forsendelse";
strRLabel = "Slet fra Indk�bsvogn";
strRButton= "Slet";
strSUB    = "SUBTOTAL";
strSHIP   = "FORSENDELSE";
strTAX    = "MOMS";
strTOT    = "TOTAL";
strErrQty = "Ugyldigt Antal.";
strNewQty = 'Angiv venligst antal:';

Language = 'dk';
bLanguageDefined = true;
