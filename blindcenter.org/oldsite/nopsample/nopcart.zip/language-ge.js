//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Entschuldigung, Ihre Bestellung ist voll, bitte zur Kasse gehen !!!";
strAdded  = " an Ihre Bestellung hinzu gef�gt.";
strRemove = "Bitte dr�cken sie 'Ok' um das Produkt zu entfernen.";
strILabel = "PRODUKT";
strQLabel = "ANZAHL";
strDLabel = "BESCHREIBUNG";
strPLabel = "PREIS";
strSLabel = "Versandkosten";
strRLabel = "KORB";
strRButton= "ENTFERNEN";
strSUB    = "ZWISCHENSUMME";
strSHIP   = "VERSANDKOSTEN";
strTAX    = "MWSt";
strTOT    = "TOTAL";
strErrQty = "Ung�ltige Anzahl.";
strNewQty = 'Bitte geben sie eine neue Anzahl ein:';

Language = 'ge';
bLanguageDefined = true;

