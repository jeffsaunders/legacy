//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Przykro nam ale twój koszyk jest pe&#322;ny"; 
strAdded  = " dodany do twojego koszyka"; 
strRemove = "Kliknij 'ok' aby wyrzuci&#263; pozycj&#281; z koszyka"; 
strILabel = "Numer 'id'"; 
strDLabel = "Nazwa produktu"; 
strQLabel = "Ilos&#263;"; 
strPLabel = "Cena"; 
strSLabel = "Dowóz"; 
strRLabel = "Usu&#324; z koszyka"; 
strRButton= "Usu&#324;"; 
strSUB    = "NETTO"; 
strSHIP   = "Dowóz"; 
strTAX    = " Podatek VAT"; 
strTOT    = "BRUTTO"; 
strErrQty = "Nieprawid&#322;owa ilo&#347;&#263;"; 
strNewQty = 'Okre&#347;l ilo&#347;&#263; towaru:';

Language = 'pl';
bLanguageDefined = true;

