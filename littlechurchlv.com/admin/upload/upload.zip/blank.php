<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<!--
Title - Sports Gaming Players Network Blank Page Placeholder 
Development Copyright 2004, Network Resources - Las Vegas, Nevada USA (www.nr.net)
Digital Art Copyright 2004, Network Resources and Sports Gaming Players Network Respectively
All Content Copyright 2004, Network Resources and Sports Gaming Players Network Respectively
Authored by Jeff S. Saunders, Network Resources 02/15/04
Modified by Jeff S. Saunders, Network Resources 10/08/04
-->

<html>
<head>
	<title>Blank Page</title>
</head>

<body>

</body>
</html>
